void counter(char number, int x, int y)
{
	if (number == 0)
	{
		gotoxy(x, y);	cout << "   ___ ";
		gotoxy(x, y + 1); cout << " //  //";
		gotoxy(x, y + 2); cout << "//__// ";
	}
	if (number == 1)
	{
		gotoxy(x, y);	cout << "       \n";
		gotoxy(x, y + 1); cout << "     //\n";
		gotoxy(x, y + 2); cout << "    // \n";
	}
	if (number == 2)
	{
		gotoxy(x, y); cout << "  ____ \n";
		gotoxy(x, y + 1); cout << "  ___//\n";
		gotoxy(x, y + 2); cout << "//___  \n";
	}
	if (number == 3)
	{
		gotoxy(x, y); cout << "   ___ \n";
		gotoxy(x, y + 1); cout << "   __//\n";
		gotoxy(x, y + 2); cout << " ___// \n";
	}
	if (number == 4)
	{
		gotoxy(x, y); cout << "       \n";
		gotoxy(x, y + 1); cout << " //__//\n";
		gotoxy(x, y + 2); cout << "    // \n";
	}
	if (number == 5)
	{
		gotoxy(x, y); cout << "   ____\n";
		gotoxy(x, y + 1); cout << " //___ \n";
		gotoxy(x, y + 2); cout << "____// \n";
	}
	if (number == 6)
	{
		gotoxy(x, y); cout << "   ___ \n";
		gotoxy(x, y + 1); cout << " //__  \n";
		gotoxy(x, y + 2); cout << "//__// \n";
	}
	if (number == 7)
	{
		gotoxy(x, y); cout << "  ____ \n";
		gotoxy(x, y + 1); cout << "     //\n";
		gotoxy(x, y + 2); cout << "    // \n";
	}
	if (number == 8)
	{
		gotoxy(x, y); cout << "   ___ \n";
		gotoxy(x, y + 1); cout << " //__//\n";
		gotoxy(x, y + 2); cout << "//__// \n";
	}
	if (number == 9)
	{
		gotoxy(x, y); cout << "   ___ \n";
		gotoxy(x, y + 1); cout << " //__//\n";
		gotoxy(x, y + 2); cout << " ___// \n";
	}
}

void encounter(int n, int x, int y)
{
	int num[2];
	if (n < 10)
	{
		counter(n, x + 8, y);
	}
	else {
		num[0] = n / 10;
		num[1] = n % 10;
		counter(num[0], x, y);
		counter(num[1], x + 8, y);
	}
	gotoxy(0, 27);
}

void number(int n)
{
	switch (n)
	{
	case 1: PlaySound(TEXT("Sounds/satu.wav"), NULL, SND_SYNC); break;
	case 2: PlaySound(TEXT("Sounds/dua.wav"), NULL, SND_SYNC); break;
	case 3: PlaySound(TEXT("Sounds/tiga.wav"), NULL, SND_SYNC); break;
	case 4: PlaySound(TEXT("Sounds/empat.wav"), NULL, SND_SYNC); break;
	case 5: PlaySound(TEXT("Sounds/lima.wav"), NULL, SND_SYNC); break;
	case 6: PlaySound(TEXT("Sounds/enam.wav"), NULL, SND_SYNC); break;
	case 7: PlaySound(TEXT("Sounds/tujuh.wav"), NULL, SND_SYNC); break;
	case 8: PlaySound(TEXT("Sounds/delapan.wav"), NULL, SND_SYNC); break;
	case 9: PlaySound(TEXT("Sounds/sembilan.wav"), NULL, SND_SYNC); break;
	case 10: PlaySound(TEXT("Sounds/sepuluh.wav"), NULL, SND_SYNC); break;
	case 11: PlaySound(TEXT("Sounds/sebelas.wav"), NULL, SND_SYNC); break;
	}
}

void play(int n, int ruang)
{
	PlaySound(TEXT("Sounds/nomor-antrian.wav"), NULL, SND_SYNC);
	char num[2];
	if (n <= 11)
	{
		number(n);
	}
	else if (n > 11 && n < 20)
	{
		n = n % 10;
		number(n);
		PlaySound(TEXT("Sounds/belas.wav"), NULL, SND_SYNC);
	}
	else {
		num[0] = n / 10;
		num[1] = n % 10;
		number(num[0]);
		PlaySound(TEXT("Sounds/puluh.wav"), NULL, SND_SYNC);
		number(num[1]);
	}
	PlaySound(TEXT("Sounds/diruang.wav"), NULL, SND_SYNC);
	if (ruang == 1)
	{
		PlaySound(TEXT("Sounds/poli-umum.wav"), NULL, SND_SYNC);
	}
	if (ruang == 2)
	{
		PlaySound(TEXT("Sounds/poli-anak.wav"), NULL, SND_SYNC);
	}
	if (ruang == 3)
	{
		PlaySound(TEXT("Sounds/poli-gigi.wav"), NULL, SND_SYNC);
	}
}
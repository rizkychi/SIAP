#define MAX 20 //define max data for queue is 30
#pragma warning(disable: 4996) //avoid error while using getch

/*-------------------------------------*/
/*    Linked List for Data patient     */
/*-------------------------------------*/

//declare struct of List 
struct Patient {
		//variabel
		int ID;
		int number;
		char gender;
		string name;
		string age;
		string address;
		string phone;
		//pointer to next node
		Patient *next;
} *temp, *head, *tail;

//initialize List
void initList()
{
	head = tail = NULL;
}

//check List
int isListEmpty()
{
	if (tail == NULL)
		return 1;
	else 
		return 0;
}

//insert new data to the List
void insert(int ID, string name, char gender, string age, string phone, string address)
{
	temp = new Patient; //order memory to save data

	//save data from parameter to List
	temp->name = name;
	temp->gender = gender;
	temp->age = age;
	temp->phone = phone;
	temp->address = address;
	temp->ID = ID;
	temp->next = NULL;
	temp->number = 0;
	if (isListEmpty() == 1)
	{
		head = tail = temp;
		tail->next = NULL;
	} else {
		tail->next = temp;
		tail = temp;
	}
}

//sort data in the List
void Sort(string key)
{
	Patient *curr, *min; //declare new pointer to sort List
	
	if (!isListEmpty())
	{
		for (temp = head; temp != NULL; temp = temp->next)
		{
			min = temp;
			for (curr = temp->next; curr != NULL; curr = curr->next)
			{
				//finding minimum value based on key
				if (key == "name")
				{
					if (curr->name < min->name)
						min = curr;
				}
				if (key == "ID")
				{
					if (curr->ID < min->ID)
						min = curr;
				}
			}
			//swapping temp data to min data
			swap(temp->ID, min->ID);
			swap(temp->name, min->name);
			swap(temp->gender, min->gender);
			swap(temp->age, min->age);
			swap(temp->phone, min->phone);
			swap(temp->address, min->address);
		}
	}
}

//delete data from List
void Delete(Patient *data)
{
	temp = head;
	if (data != head)
	{
		//search node before node data
		while (temp->next != data)
		{
			temp = temp->next;
		}
		//change node link to next data link
		temp->next = data->next;
	}
	else
	{
		//change first node
		head = head->next;
	}
	//free memory used
	delete data;
}

/*-------------------------------------*/
/*  	Queue for Antrian patient      */
/*-------------------------------------*/

//declare struct of queue
struct queue
{
	//variabel
	Patient *antre[MAX];
	int first, last, count;

	//initialize the queue
	void init()
	{
		first = last = -1;
		count = 0;
	}

	//check queue
	int isQueueFull()
	{
		if (last == MAX - 1)
			return 1;
		else
			return 0;
	}

	//check queue
	int isQueueEmpty()
	{
		if (last == -1)
			return 1;
		else
			return 0;
	}

	//insert patient to queue
	void enQueue(Patient *data)
	{
		if (!isQueueFull())
		{
			antre[last] = data;
			last++; count++;
			data->number = count;
		}
		else 
		{
			
		}
	}

	//delete patient from queue
	int deQueue()
	{
		if (!isQueueEmpty())
		{
			antre[first]->number = 0;
			for (int i = first; i<last; i++)
			{
				antre[i] = antre[i + 1];
			}
			last--;
			return 1;
		}
		else 
		{
			return 0;
		}
	}

	//clear/delete all patient from queue
	void clear()
	{
		init();
	}
} Q_umum, Q_anak, Q_gigi; //3 types of queue

/*-------------------------------------*/
/*           Other Function            */
/*-------------------------------------*/

//function to generate new ID
int generateID()
{
	int lastID;
	if (!isListEmpty())
		lastID = tail->ID;
	else
		lastID = 1000;
	return lastID + 1;
}

//function to search data in the List based on ID
Patient *search(int ID)
{
	//function to search ID
	int found = 0;
	for (temp = head; temp != NULL; temp = temp->next)
	{
		if (ID == temp->ID)
		{
			found = 1;
			break;
		}
	}
	if (found == 1)
		return temp;
	else
		return NULL;
}

/*
	Name: Sistem Informasi Antrean Pasien (SIAP)
	Copyright: 2018 � Onion Team
	Author: Onion Team
	Description: This software is made to fulfill the Data Structure's Final Project 
*/

/*------------------------Note: IMPORTANT!--------------------------!!
!!	Add this command to compiler before build this code :			!!
!!	-lwinmm    (DEVC++ -> compiler option -> add following command) !!
!!		or															!!
!!	winmm.lib  (VisualStudio -> linker -> input)					!!
!!------------------------------------------------------------------*/

#include <iostream>
#include <conio.h>
#include <windows.h>
#include <string>
#include <iomanip>
#include "Config.h"
#include "data.h"
#include "counter.h"
#include "function.h"
#include "db.h"

using namespace std;

//main program
int main()
{	
	//initialize List and Queue
	initList();
	Q_umum.init(); Q_anak.init(); Q_gigi.init();

	//import data from database
	dbImport(); 
	
	//declare variabel
	char menu;

	do
	{
		attribute(); //set attribute (widht, height, color)
		system("cls");
		system("title Sistem Informasi Antrean Pasien");
		title(); //show the title
		line(49, 11, 22);
		gotoxy(51, 12);
		cout << "M E N U  U T A M A\n";
		line(49, 13, 22);
		gotoxy(32, 15); cout << "[1] Proses Antrean";  gotoxy(62, 15); cout << "[5] Registrasi Pasien Baru";
		gotoxy(32, 17); cout << "[2] Lihat Semua Antrean";   gotoxy(62, 17); cout << "[6] Lihat Semua Data Pasien";
		gotoxy(32, 19); cout << "[3] Tambah Pasien ke Antrean";  gotoxy(62, 19); cout << "[7] Cari/Ubah Data Pasien";
		gotoxy(32, 21); cout << "[4] Reset Semua Antrean";   gotoxy(62, 21); cout << "[0] Keluar Program";

		gotoxy(48,25);
		cout << "Tekan salah satu menu...";
		menu = getch();
		switch (menu)
		{
			case '1' : process_queue(); break;
			case '2' : show_queue(); break;
			case '3' : insert_queue(); break;
			case '4' : reset_queue(); break;
			case '5' : reg_patient(); break;
			case '6' : show_patient(); break;
			case '7' : search_patient(); break;
		}
	} while (menu != '0');

	dbExport(); //export data to database
	return 0;
}

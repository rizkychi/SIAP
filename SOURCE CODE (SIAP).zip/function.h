int umum = 0, anak = 0, gigi = 0; //declare 3 variables to count the queue

void process_queue();
void show_queue();
void insert_queue();
void reset_queue();
void reg_patient();
void show_patient();
void search_patient();
void update_patient(Patient *data);

void process_queue()
{	
	system("title Proses Antrean Pasien");
	char opsi;
	do {
		system("cls");

		//draw table coloumn
		for (int i = 1; i < 17; i++)
		{
			gotoxy(13, i + 5);
			cout << "|";
			gotoxy(44, i + 5);
			cout << "|";
			gotoxy(75, i + 5);
			cout << "|";
			gotoxy(106, i + 5);
			cout << "|";
		}
		//draw table row
		line(13, 5, 94);
		line(13, 7, 94);
		line(13, 18, 94);
		line(13, 21, 94);
		line(13, 23, 94);

		//write title
		line(48, 1, 24);
		gotoxy(49, 2); cout << "Proses  Antrean Pasien";
		line(48, 3, 24);
		gotoxy(24, 6); cout << "Poli Umum";
		gotoxy(55, 6); cout << "Poli Anak";
		gotoxy(86, 6); cout << "Poli Gigi";
	
		//write menu
		gotoxy(15, 19); cout << "[1] Antrean berikutnya";
		gotoxy(15, 20); cout << "[Q] Ulangi antrean";
		gotoxy(46, 19); cout << "[2] Antrean berikutnya";
		gotoxy(46, 20); cout << "[W] Ulangi antrean";
		gotoxy(77, 19); cout << "[3] Antrean berikutnya";
		gotoxy(77, 20); cout << "[E] Ulangi antrean";
		gotoxy(13, 22); cout << "|"; gotoxy(55, 22); cout << "[0] Keluar"; gotoxy(106, 22); cout << "|";

		//Initialize counter
		encounter(umum, 21, 11);
		encounter(anak, 52, 11);
		encounter(gigi, 83, 11);
		
		gotoxy(0, 27); opsi = getch();
		switch (opsi)
		{
			case '1': if (Q_umum.deQueue() == 1){umum++; encounter(umum, 21, 11); play(umum, 1);} break;
			case '2': if (Q_anak.deQueue() == 1){anak++; encounter(anak, 52, 11); play(anak, 2);} break;
			case '3': if (Q_gigi.deQueue() == 1){gigi++; encounter(gigi, 83, 11); play(gigi, 3);} break;
			case 'q':;
			case 'Q': if (umum != 0) play(umum, 1); break;
			case 'w':;
			case 'W': if (anak != 0) play(anak, 2); break;
			case 'e':;
			case 'E': if (gigi != 0) play(gigi, 3); break;
		}
	} while (opsi != '0');
}

//function to show current queue
void show_queue()
{
	system("cls");
	system("title Antrean Pasien");

	//draw table coloumn
	for (int i = 1; i <= 22; i++)
	{
		gotoxy(40, i + 2);
		cout << "|";
		gotoxy(80, i + 2);
		cout << "|";
	}
	
	//draw table row
	line(0, 0, 120);
	line(0, 2, 120);
	line(0, 4, 120);
	line(0, 25, 120);
	
	//write title
	gotoxy(50, 1); cout << "Daftar Antrean Pasien";
	gotoxy(15, 3); cout << "Poli Umum";
	gotoxy(56, 3); cout << "Poli Anak";
	gotoxy(97, 3); cout << "Poli Gigi";
	
	//write queue
	for (int i = Q_umum.first; i < Q_umum.last; i++)
	{
		gotoxy(1, 6 + i);
		cout << setw(2) << Q_umum.antre[i]->number << "-";
		cout << Q_umum.antre[i]->ID << "-";
		cout << Q_umum.antre[i]->name << endl;
	}
	for (int i = Q_anak.first; i < Q_anak.last; i++)
	{
		gotoxy(42, 6 + i);
		cout << setw(2) << Q_anak.antre[i]->number << "-";
		cout << Q_anak.antre[i]->ID << "-";
		cout << Q_anak.antre[i]->name << endl;
	}
	for (int i = Q_gigi.first; i < Q_gigi.last; i++)
	{
		gotoxy(82, 6 + i);
		cout << setw(2) << Q_gigi.antre[i]->number << "-";
		cout << Q_gigi.antre[i]->ID << "-";
		cout << Q_gigi.antre[i]->name << endl;
	}

	gotoxy(0, 27);
	system("pause");
}

//insert patient to queue
void insert_queue()
{
	system("cls");
	system("title Tambah Pasien ke Antrean");

	//declare variables
	char ch, text[100];
	int ID;
	Patient *find;

	line(46, 3, 28);
	gotoxy(48, 4); cout << "Tambah Pasien ke Antrean";
	line(46, 5, 28);

	gotoxy(55, 7); cout << "ID : "; cin >> ID; cin.ignore();
	find = search(ID);

	if (find != NULL && find->number == 0)
	{
		//show result
		MessageBox(0, "Data ditemukan!", "Search Patient", MB_OK | MB_ICONINFORMATION);
		line(30, 8, 60);
		gotoxy(54, 9); cout << "Pilih layanan";
		line(30, 10, 60);
		gotoxy(32, 11); cout << "[1] Poli Umum         [2] Poli Anak        [3] Poli Gigi";

		gotoxy(0, 27);
		ch = getch();
		switch (ch)
		{
			case '1': Q_umum.enQueue(find); break;
			case '2': Q_anak.enQueue(find); break;
			case '3': Q_gigi.enQueue(find); break;
		}
		sprintf(text, "Sukses!\nID Pasien : %d\nNama Pasien : %s\nNomor Antrean : %d", find->ID, find->name.c_str(), find->number);
		MessageBox(0, text, "Insert Patient to Queue", MB_OK | MB_ICONINFORMATION);
	}
	else if (find != NULL && find->number != 0)
	{
		MessageBox(0, "Pasien sudah terdaftar di antrean!", "Search Patient", MB_OK | MB_ICONERROR);
	}
	else
	{
		//if not found
		if (MessageBox(0, "Data tidak ditemukan!", "Search Patient", MB_RETRYCANCEL | MB_ICONERROR) == 4)
			insert_queue();
	}
}

//function to reset/clear all queue
void reset_queue()
{
	if (MessageBox(0, "Apakah anda yakin ingin mereset antrean?", "Reset Queue", MB_OKCANCEL | MB_ICONWARNING) == 1)
	{
		Q_umum.clear();
		Q_anak.clear();
		Q_gigi.clear();
		umum = anak = gigi = 0;
	}
}

//function to register new patient
void reg_patient()
{
	//variables
	int ID;
	char gender;
	string name;
	string age;
	string address;
	string phone;

	system("title Registrasi Pasien Baru");
	system("cls");
	line(48, 2, 24);
	gotoxy(50, 3);
	cout<<"MASUKKAN DATA PASIEN";
	line(48, 4, 24);

	cout<<"\n\n\n\tNama Lengkap\t:\n\n";
	cout<<"\tJenis Kelamin\t:\n\n";
	cout<<"\tUmur\t\t:\n\n";
	cout<<"\tNo. Telp\t:\n\n";
	cout<<"\tAlamat\t\t:\n\n";
	
	//form data input
	gotoxy(26, 7);
	getline(cin, name);
	gotoxy(26, 9);
	do
	{
		gender = getch();
	} while (gender != 'L' && gender != 'l' && gender != 'P' && gender != 'p');
	cout << gender;
	gotoxy(26, 11);
	getline(cin, age);
	gotoxy(26, 13);
	getline(cin, phone);
	gotoxy(26, 15);
	getline(cin, address);

	//cut string
	name = name.substr(0, 25);
	age = age.substr(0, 3);
	phone = phone.substr(0, 13);
	address = address.substr(0, 50);
	ID = generateID();

	//insert data to list
	insert(ID, name, toupper(gender), age, phone, address);

	//make a popup to inform the ID
	char text[100];
	sprintf(text, "Sukses!\nID Pasien : %d\nNama Pasien : %s", ID, name.c_str());
	MessageBox(0, text, "Register New Patient", MB_OK | MB_ICONINFORMATION);
}

void show_patient()
{
	system("title Data Pasien");

	int i = 1; //numbering
	bool finished = FALSE; //check all data have been listed or not
	Patient *page;

	//show all data in the List
	page = head; //initialize page = head
	if (isListEmpty() == 0)
	{
		while (!finished)
		{
			system("cls");
			line(0, 0, 120);
			gotoxy(55, 1);
			cout << "DAFTAR PASIEN";
			line(0, 2, 120);
			cout << " No.|   ID   |           Nama           | JK | Umur |    Telepon    |\t\t\t   Alamat";
			line(0, 4, 120);
			//draw coloumn
			for (int j = 0; j <= 20; j++)
			{
				gotoxy(4, 5 + j); cout << "|";
				gotoxy(13, 5 + j); cout << "|";
				gotoxy(40, 5 + j); cout << "|";
				gotoxy(45, 5 + j); cout << "|";
				gotoxy(52, 5 + j); cout << "|";
				gotoxy(68, 5 + j); cout << "|";
			}
			cout << endl;
			int row = 1; //variable to set value Y on gotoxy
			for (temp = page; temp != NULL; temp = temp->next)
			{
				gotoxy(0, 4 + row);  cout << setw(3) << i;
				gotoxy(6, 4 + row);  cout << setw(5) << temp->ID;
				gotoxy(15, 4 + row); cout << temp->name;
				gotoxy(42, 4 + row); cout << temp->gender;
				gotoxy(48, 4 + row); cout << setw(3) << temp->age;
				gotoxy(54, 4 + row); cout << temp->phone;
				gotoxy(70, 4 + row); cout << temp->address;
				i++; row++; //increment
				//condition to split between page
				if (row % 20 == 1)
				{
					page = temp->next;
					break;
				}
				//condition to finish when all data have been listed
				if (temp == tail)
				{
					finished = true;
				}
			}
			
			line(0, 25, 120);
			gotoxy(0, 26);
			cout << " Pilih Menu :\n";
			cout << " [1] Urutkan berdasarkan ID    [2] Urutkan berdasarkan nama    [3] Cari data    [4] Halaman Selanjutnya    [0] Keluar";
			char ch;
			gotoxy(14, 26);
			ch = getch();
			switch (ch)
			{
				case '1': finished = TRUE; Sort("ID"); show_patient(); break;
				case '2': finished = TRUE; Sort("name"); show_patient(); break;
				case '3': finished = TRUE; search_patient(); break;
				case '4': break;
				case '0': finished = TRUE; break;
			}
			
		}
		Sort("ID");
	}
	else
	{
		MessageBox(0, "Belum ada pasien!", "Show Patient", MB_OK | MB_ICONWARNING);
	}
}

void search_patient()
{
	system("cls");
	system("title Cari Data Pasien");

	line(46, 3, 28);
	gotoxy(48, 4); cout << "Masukkan nomor ID Pasien";
	line(46, 5, 28);

	//form input ID
	char ch;
	int ID;
	gotoxy(55, 7); cout << "ID : "; cin >> ID; cin.ignore();

	//searching
	Patient *find;
	find = search(ID);

	if (find != NULL)
	{
		//show result
		MessageBox(0, "Data ditemukan!", "Search Patient", MB_OK | MB_ICONINFORMATION);
		do
		{
			system("cls");
			line(46, 3, 28);
			gotoxy(48, 4); cout << "Masukkan nomor ID Pasien";
			line(46, 5, 28);
			gotoxy(55, 7); cout << "ID : " << ID;

			line(30, 9, 60);
			gotoxy(30, 10); cout << "ID\t\t: " << find->ID;
			gotoxy(30, 11); cout << "Nama Lengkap\t: " << find->name;
			gotoxy(30, 12); cout << "Jenis Kelamin\t: " << find->gender;
			gotoxy(30, 13); cout << "Umur\t\t: " << find->age;
			gotoxy(30, 14); cout << "No. Telp\t\t: " << find->phone;
			gotoxy(30, 15); cout << "Alamat\t\t: " << find->address;
			line(30, 16, 60);
			//options to update/delete data
			gotoxy(42, 17); cout << "[1] Ubah    [2] Hapus    [0] Keluar";
			gotoxy(0, 27);
			ch = getch();
			switch (ch)
			{
			case '1': update_patient(find); break;
			case '2': if (MessageBox(0, "Apakah anda yakin ingin menghapus data pasien ini?", "Delete Patient", MB_YESNO | MB_ICONWARNING) == 6)
					  {
						  Delete(find);
						  MessageBox(0, "Data pasien telah terhapus!", "Delete Patient", MB_OK | MB_ICONINFORMATION);
						  ch = '0';
					  }
					  break;
			case '0': break;
			}
		} while (ch != '0');
	}
	else
	{
		//if not found
		if (MessageBox(0, "Data tidak ditemukan!", "Search Patient", MB_RETRYCANCEL | MB_ICONERROR) == 4)
			search_patient();
	}
}

void update_patient(Patient *data)
{
	char ch;

	line(30, 18, 60);
	gotoxy(46, 19); cout << "Pilih data yang akan diubah";
	gotoxy(36, 20); cout << "[1] Nama   [2] Umur   [3] No. Telp   [4] Alamat";
	gotoxy(0, 27);
	ch = getch();
	line(30, 21, 60);
	gotoxy(30, 22);
	switch (ch)
	{
		case '1': cout << "Nama lengkap : "; getline(cin, data->name); 	  data->name = data->name.substr(0, 25); break;
		case '2': cout << "Umur : ";		 getline(cin, data->age);	  data->age = data->age.substr(0, 3); break;
		case '3': cout << "No. Telp : ";	 getline(cin, data->phone);   data->phone = data->phone.substr(0, 13); break;
		case '4': cout << "Alamat : ";		 getline(cin, data->address); data->address = data->address.substr(0, 50); break;
	}
	MessageBox(0, "Data telah diubah!", "Update Patient", MB_OK | MB_ICONINFORMATION);
}

void title()
{
	gotoxy(40, 2); cout << "     __________  ___  _________  _________"; Sleep(50);
	gotoxy(40, 3); cout << "    /  _______/ /  / /  ___   / /  ___   /"; Sleep(50);
	gotoxy(40, 4); cout << "   /  /______  /  / /  /__/  / /  /__/  /"; Sleep(50);
	gotoxy(40, 5); cout << "  /______   / /  / /  ___   / /  ______/"; Sleep(50);
	gotoxy(40, 6); cout << " _______/  / /  / /  /  /  / /  /"; Sleep(50);
	gotoxy(40, 7); cout << "/_________/ /__/ /__/  /__/ /__/"; Sleep(50);
	gotoxy(40, 9); cout << "----\"Sistem Informasi Antrean Pasien\"----"; Sleep(50);
}


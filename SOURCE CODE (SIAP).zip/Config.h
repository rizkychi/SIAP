#include <iostream>
using namespace std;

//function to define gotoxy
void gotoxy(int x, int y){
	COORD coord;
	coord.X = x;
	coord.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}

//function to draw the line
void line(int x, int y, int n, char c = '-')
{
	gotoxy(x, y);
	for (int i = 0; i < n; ++i)
	{
		cout<<c;
	}
}

//function to set attribut console
void attribute()
{	
	//set color and background
  	system("color F0");	
	//set width and height
	HWND console = GetConsoleWindow();
	RECT r;
	GetWindowRect(console, &r);
	MoveWindow(console, r.left, r.top, 993, 500, TRUE);
}

//use for SetConsoleTextAttribute
HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);

//Note: IMPORTANT!
/*
	Add this command to compiler before build this code
	
	-lwinmm    (DEVC++ -> compiler option -> add following command)
	or
	winmm.lib  (VisualStudio -> linker -> input)
*/
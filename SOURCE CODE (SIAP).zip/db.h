#pragma once
#include <fstream>
#include <sstream>

void dbExport()
{
	ofstream db_patient ("list.db", ofstream::out | ofstream::trunc);

	for (temp = head; temp != NULL; temp = temp->next)
	{
		if (!db_patient.fail())
		{
			db_patient << temp->ID << "#";
			db_patient << temp->name << "#";
			db_patient << temp->gender << "#";
			db_patient << temp->age << "#";
			db_patient << temp->phone << "#";
			db_patient << temp->address << "\n";
		}
	}
	db_patient.close();
}

void dbImport()
{
	string line;
	string ID, gender;
	ifstream db_patient ("list.db");

	while (getline(db_patient, line))
	{
		stringstream linestream(line);

		temp = new Patient;
		temp->next = NULL;
		temp->number = 0;

		getline(linestream, ID, '#'); temp->ID = atoi(ID.c_str());
		getline(linestream, temp->name, '#');
		getline(linestream, gender, '#'); temp->gender = gender[0];
		getline(linestream, temp->age, '#');
		getline(linestream, temp->phone, '#');
		getline(linestream, temp->address, '#');

		if (isListEmpty() == 1)
		{
			head = tail = temp;
			tail->next = NULL;
		}
		else {
			tail->next = temp;
			tail = temp;
		}
		
	}

}